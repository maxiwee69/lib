# Eneko
Set a video as your wallpaper

## Installation
1. Add this repository to your Package Manager: https://repo.litten.love
2. Install Eneko

## Compiling
  - Depends on libGcUniversal
  - You may want to edit the `Makefiles` to suit your theos installation

## License
If you take code from this repository please link it, or my [twitter](https://twitter.com/schneelittchen) to your project  
You may not redistribute this source code or packages from it  
You may not use this project to make profit like money

## Credits
  - Lock Screen Camera Hook
    - [MrGcGamer](https://twitter.com/MrGcGamer)
  - Icon and Banner
    - [74k1_](https://twitter.com/74k1_)
  - Duo twitter cell
    - [arm64e](https://twitter.com/arm64e), [MrGcGamer](https://twitter.com/MrGcGamer)